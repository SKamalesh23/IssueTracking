import React from "react";
import './styl.css';
import 'bootstrap/dist/css/bootstrap.css';
function Footer1() {
    return (
      <footer style={{position:"fixed",bottom:0}} className="footer">
        <p>&copy; 2024 Engineering College. All rights reserved.</p>
      </footer>
    );
  }
  export default Footer1;